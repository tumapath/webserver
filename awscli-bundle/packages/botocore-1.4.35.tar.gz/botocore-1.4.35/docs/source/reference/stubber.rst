.. ref_stubber:

=================
Stubber Reference
=================

botocore.stub
-------------

.. autoclass:: botocore.stub.Stubber
   :members:
