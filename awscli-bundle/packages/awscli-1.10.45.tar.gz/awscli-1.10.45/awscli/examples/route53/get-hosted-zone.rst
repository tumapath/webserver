**To get information about a hosted zone**

The following ``get-hosted-zone`` command gets information about the hosted zone with an ``id`` of ``Z1R8UBAEXAMPLE``::

  aws route53 get-hosted-zone --id Z1R8UBAEXAMPLE
